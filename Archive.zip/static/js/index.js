$(document).ready(function() {
	$("#header").load("header.html");
});
function login_page() {
	window.location.href = "login.html";
}
function signup_page() {
	window.location.href = "signup.html";
}