function logout() {
	window.localStorage.removeItem("id");
	window.location.href = "index.html";
}
function myprofile() {
	window.location.href = "profile.html";
}
function postrecipe() {
	window.location.href = "postrecipe.html";
}
function leaderboard() {
	window.location.href = "leaderboard.html";
}
function searchrecipe() {
	window.location.href = "search.html";
}